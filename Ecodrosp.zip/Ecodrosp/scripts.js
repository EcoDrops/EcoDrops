// Función para detectar si un elemento es visible en la ventana
function isVisible(element) {
    const elementPosition = element.getBoundingClientRect();
    return (
        elementPosition.top >= 0 &&
        elementPosition.bottom <= (window.innerHeight || document.documentElement.clientHeight)
    );
}

// Aplicar clase de animación cuando el elemento se vuelve visible
document.addEventListener('scroll', function() {
    const sections = document.querySelectorAll('.content, header');
    sections.forEach(function(section) {
        if (isVisible(section)) {
            section.classList.add('visible'); // Añade la clase para la animación
        }
    });
});

// Ejecutar la función al cargar la página para animar los elementos ya visibles
document.addEventListener('DOMContentLoaded', function() {
    const sections = document.querySelectorAll('.content, header');
    sections.forEach(function(section) {
        if (isVisible(section)) {
            section.classList.add('visible'); // Añade la clase si ya son visibles
        }
    });
});
